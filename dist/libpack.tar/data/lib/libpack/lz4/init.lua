local lib = {}
lib.lz4_encode =  require("libpack.lz4.encode")
lib.lz4_decode = require("libpack.lz4.decode")
return lib
