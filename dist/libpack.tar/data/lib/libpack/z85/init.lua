local lib = {}
lib.z85_decode = require("libpack.z85.decode")
lib.z85_encode = require("libpack.z85.encode")
return lib
