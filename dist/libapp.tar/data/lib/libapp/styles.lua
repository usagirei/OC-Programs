local Styles = {}

Styles.Progress = require("libapp.style.progress")
Styles.Track = require("libapp.style.track")
Styles.Border = require("libapp.style.border")
Styles.CheckBox = require("libapp.style.checkbox")
Styles.Decorator = require("libapp.style.decorator")
Styles.Separator = require("libapp.style.separator")

return Styles
